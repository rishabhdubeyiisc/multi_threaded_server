System.register(["./chunk-vendor.js"],(function(){"use strict";return{setters:[function(){}],execute:function(){}}}));
//# sourceMappingURL=primer-c094373e.js.map
